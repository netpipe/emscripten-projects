# Copyright (c) 2014 The Native Client Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

export EMACS_X=1
START_DIR=${START_DIR}/../emacs
cd ${START_DIR}
. build.sh
