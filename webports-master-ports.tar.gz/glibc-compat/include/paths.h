/*
 * Copyright 2015 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */
#ifndef GLIBCEMU_PATHS_H
#define GLIBCEMU_PATHS_H 1

#include_next <paths.h>
#define _PATH_TTY        "/dev/tty"

#endif /* GLIBCEMU_PATHS_H */
