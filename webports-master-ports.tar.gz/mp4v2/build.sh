# Copyright 2014 The Native Client Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.

EXECUTABLES="mp4tags${NACL_EXEEXT} mp4info${NACL_EXEEXT}"
NACLPORTS_CPPFLAGS+=" ${NACL_EXCEPTIONS_FLAG}"
EnableGlibcCompat
